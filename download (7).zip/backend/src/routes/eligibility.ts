import { Hono } from 'hono';
import { checkEligibility } from '../utils/eligibility.ts';

const eligibilityRoutes = new Hono();

eligibilityRoutes.post('/check-eligibility', async (c) => {
  const body = await c.req.json();
  const { state, schemeName } = body;

  const result = checkEligibility(state, schemeName);

  if (result.status === 'Eligible') {
    return c.json({
      eligibilityStatus: 'Eligible',
      monthlyBenefitAmount: result.amount
    });
  }

  return c.json({
    eligibilityStatus: 'Not Eligible',
    monthlyBenefitAmount: 0
  });
});

export default eligibilityRoutes;
