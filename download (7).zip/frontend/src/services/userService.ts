import { api } from '../lib/api.ts';
import { UserProfile } from '../types';

export const userService = {
  async getAllUsers() {
    const response = await api.get('/users');
    return response.data;
  },

  async getProfile() {
    const response = await api.get('/users/profile');
    return response.data;
  },

  async updateProfile(data: Partial<UserProfile>) {
    const response = await api.patch('/users/profile', data);
    return response.data;
  },

  async lockSavings(durationDays: number) {
    const response = await api.post('/users/lock-savings', { durationDays });
    return response.data;
  }
};
