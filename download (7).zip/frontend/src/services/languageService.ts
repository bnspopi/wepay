export const stateLanguages: any = {
  "West Bengal": "bn",
  "Odisha": "or",
  "Bihar": "hi",
  "Jharkhand": "hi",
  "Uttar Pradesh": "hi",
  "Madhya Pradesh": "hi",
  "Chhattisgarh": "hi",
  "Rajasthan": "hi",
  "Haryana": "hi",
  "Punjab": "pa",
  "Gujarat": "gu",
  "Maharashtra": "mr",
  "Goa": "mr",
  "Tamil Nadu": "ta",
  "Karnataka": "kn",
  "Kerala": "ml",
  "Andhra Pradesh": "te",
  "Telangana": "te",
  "Assam": "as",
  "Meghalaya": "hi",
  "Tripura": "bn",
  "Manipur": "hi",
  "Mizoram": "hi",
  "Nagaland": "hi",
  "Arunachal Pradesh": "hi",
  "Sikkim": "hi"
};

export const translations: any = {
  en: {
    sendMoney: "Send Money",
    addFunds: "Add Funds",
    wallet: "Digital Wallet",
    location: "Location",
    balance: "Balance"
  },
  hi: {
    sendMoney: "पैसे भेजें",
    addFunds: "पैसे जोड़ें",
    wallet: "डिजिटल वॉलेट",
    location: "स्थान",
    balance: "बैलेंस"
  },
  bn: {
    sendMoney: "টাকা পাঠান",
    addFunds: "টাকা যোগ করুন",
    wallet: "ডিজিটাল ওয়ালেট",
    location: "অবস্থান",
    balance: "ব্যালেন্স"
  },
  or: {
    sendMoney: "ଟଙ୍କା ପଠାନ୍ତୁ",
    addFunds: "ଟଙ୍କା ଯୋଡନ୍ତୁ",
    wallet: "ଡିଜିଟାଲ ୱାଲେଟ",
    location: "ଅବସ୍ଥାନ",
    balance: "ବ୍ୟାଲାନ୍ସ"
  },
  ta: {
    sendMoney: "பணம் அனுப்பு",
    addFunds: "பணம் சேர்",
    wallet: "டிஜிட்டல் வாலெட்",
    location: "இருப்பிடம்",
    balance: "இருப்பு"
  },
  te: {
    sendMoney: "డబ్బు పంపండి",
    addFunds: "డబ్బు జోడించండి",
    wallet: "డిజిటల్ వాలెట్",
    location: "స్థానం",
    balance: "బ్యాలెన్స్"
  },
  kn: {
    sendMoney: "ಹಣ ಕಳುಹಿಸಿ",
    addFunds: "ಹಣ ಸೇರಿಸಿ",
    wallet: "ಡಿಜಿಟಲ್ ವಾಲೆಟ್",
    location: "ಸ್ಥಳ",
    balance: "ಬ್ಯಾಲೆನ್ಸ್"
  },
  ml: {
    sendMoney: "പണം അയയ്ക്കുക",
    addFunds: "പണം ചേർക്കുക",
    wallet: "ഡിജിറ്റൽ വാലറ്റ്",
    location: "സ്ഥലം",
    balance: "ബാലൻസ്"
  },
  mr: {
    sendMoney: "पैसे पाठवा",
    addFunds: "पैसे जोडा",
    wallet: "डिजिटल वॉलेट",
    location: "स्थान",
    balance: "बॅलन्स"
  },
  gu: {
    sendMoney: "પૈસા મોકલો",
    addFunds: "પૈસા ઉમેરો",
    wallet: "ડિજિટલ વોલેટ",
    location: "સ્થાન",
    balance: "બેલેન્સ"
  },
  pa: {
    sendMoney: "ਪੈਸੇ ਭੇਜੋ",
    addFunds: "ਪੈਸੇ ਜੋੜੋ",
    wallet: "ਡਿਜ਼ੀਟਲ ਵਾਲਿਟ",
    location: "ਟਿਕਾਣਾ",
    balance: "ਬਕਾਇਆ"
  },
  as: {
    sendMoney: "টকা পঠাও",
    addFunds: "টকা যোগ কৰক",
    wallet: "ডিজিটেল ৱালেট",
    location: "অৱস্থান",
    balance: "বেলেঞ্চ"
  }
};
