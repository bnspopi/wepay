import { api } from '../lib/api.ts';

export const getWalletBalance = async () => {
  const response = await api.get('/wallet/balance');
  const data = response.data;
  return typeof data === 'number' ? data : data.balance;
};

export const addFunds = async (amount: number) => {
  const response = await api.post('/wallet/add-funds', { amount });
  return response.data;
};