import { api } from '../lib/api';

export interface LoginPayload {
  email: string;
  password?: string;
}

export interface RegisterPayload {
  email: string;
  password?: string;
  name: string;
  state?: string;
  district?: string;
  village?: string;
  language?: string;
}

export const authService = {
  async login(payload: LoginPayload) {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      const usersStr = localStorage.getItem('mock_users') || '[]';
      const users = JSON.parse(usersStr);
      let user = users.find((u: any) => u.email === payload.email);
      
      if (!user) {
        user = {
          id: 'mock-user-' + Math.random().toString(36).substring(7),
          email: payload.email,
          name: payload.email.split('@')[0],
          did: `did-demo-${Date.now()}`,
          onboarded: true,
          role: 'user',
          balance: 5000,
          location: 'India'
        };
        users.push(user);
        localStorage.setItem('mock_users', JSON.stringify(users));
      }
      
      localStorage.setItem('accessToken', 'mock-token');
      localStorage.setItem('refreshToken', 'mock-refresh-token');
      localStorage.setItem('d welfare_user', JSON.stringify(user));
      return { user, accessToken: 'mock-token' };
    }
    const response = await api.post('/auth/login', payload);
    const { user, accessToken, refreshToken } = response.data;
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('refreshToken', refreshToken);
    localStorage.setItem('d welfare_user', JSON.stringify(user));
    return response.data;
  },

  async register(payload: RegisterPayload) {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      const usersStr = localStorage.getItem('mock_users') || '[]';
      const users = JSON.parse(usersStr);
      let user = users.find((u: any) => u.email === payload.email);

      if (user) {
        throw new Error('User already exists');
      }

      user = {
        id: 'mock-user-' + Math.random().toString(36).substring(7),
        email: payload.email,
        name: payload.name,
        did: `did-demo-${Date.now()}`,
        onboarded: true,
        role: 'user',
        balance: 5000,
        location: `${payload.state || 'Odisha'}, India`
      };
      
      users.push(user);
      localStorage.setItem('mock_users', JSON.stringify(users));
      
      localStorage.setItem('accessToken', 'mock-token');
      localStorage.setItem('refreshToken', 'mock-refresh-token');
      localStorage.setItem('d welfare_user', JSON.stringify(user));
      return { user, accessToken: 'mock-token' };
    }
    const response = await api.post('/auth/register', payload);
    const { user, accessToken, refreshToken } = response.data;
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('refreshToken', refreshToken);
    localStorage.setItem('d welfare_user', JSON.stringify(user));
    return response.data;
  },

  async getMe() {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      const data = localStorage.getItem('d welfare_user');
      return data ? JSON.parse(data) : null;
    }
    const response = await api.get('/auth/me');
    return response.data.user;
  },

  logout() {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('d welfare_user');
  }
};