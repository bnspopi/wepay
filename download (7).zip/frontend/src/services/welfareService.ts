import { emitter } from '@/agentSdk';
import { api } from '../lib/api';
import { UserProfile, VerifiableCredential, WelfareScheme } from '../types';
import { MOCK_CREDENTIALS, MOCK_SCHEMES } from '../data/mockData';
import { getWalletBalance } from './walletService';

const AGENTS = {
  ONBOARDING: '6fe83d52-563f-4ba8-865b-e494f927549d',
  WEPAY: '657cb613-4644-4143-b2a1-4d836117296d'
};

const STORAGE_KEYS = {
  USER: 'd welfare_user',
  OFFLINE_TRANSACTIONS: 'wepay_offline_transactions'
};

export const welfareService = {
  getUser: (): UserProfile | null => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    return data ? JSON.parse(data) : null;
  },

  setUser: (user: UserProfile) => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },

  getOfflineTransactions: (): any[] => {
    const data = localStorage.getItem(STORAGE_KEYS.OFFLINE_TRANSACTIONS);
    return data ? JSON.parse(data) : [];
  },

  saveOfflineTransaction: (tx: any) => {
    const txs = welfareService.getOfflineTransactions();
    txs.push({ ...tx, id: `offline-${Date.now()}`, status: 'offline' });
    localStorage.setItem(STORAGE_KEYS.OFFLINE_TRANSACTIONS, JSON.stringify(txs));
  },

  clearOfflineTransactions: () => {
    localStorage.removeItem(STORAGE_KEYS.OFFLINE_TRANSACTIONS);
  },

  initializeMock() {
    // No default user initialization to allow dynamic Supabase users
  },

  async getProfile(): Promise<UserProfile> {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      const user = this.getUser()!;
      return { ...user, balance: await getWalletBalance() };
    }
    const response = await api.get('/users/profile');
    const user = response.data;
    this.setUser(user);
    return user;
  },

  async updateProfile(profile: Partial<UserProfile>): Promise<UserProfile> {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      const user = this.getUser()!;
      const updated = { ...user, ...profile };
      this.setUser(updated);
      return updated;
    }
    const response = await api.patch('/users/profile', profile);
    return response.data;
  },

  async getUsers(): Promise<UserProfile[]> {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      return [];
    }
    const response = await api.get('/users');
    return response.data;
  },

  async getCredentials(): Promise<VerifiableCredential[]> {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      return MOCK_CREDENTIALS;
    }
    const response = await api.get('/credentials');
    return response.data;
  },

  async getSchemes(): Promise<WelfareScheme[]> {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      return MOCK_SCHEMES;
    }
    const response = await api.get('/welfare/schemes');
    return response.data;
  },

  async getTransactions() {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
        const offline = this.getOfflineTransactions();
        const manualTransactions = JSON.parse(localStorage.getItem("transactions") || "[]").map((tx: any) => ({
          ...tx,
          status: 'completed',
          createdAt: new Date(tx.id).toISOString(),
          receiverId: 'demo-user-2'
        }));
        return [...offline, ...manualTransactions, { id: '1', amount: 500, type: 'p2p', status: 'completed', createdAt: new Date().toISOString(), receiverId: 'user-2' }];
    }
    const response = await api.get('/transactions');
    return response.data;
  },

  async createTransaction(txData: { receiverId: string, amount: number, description?: string }) {
    // Check internet connection
    if (!navigator.onLine) {
        this.saveOfflineTransaction(txData);
        // Update local balance
        const user = this.getUser();
        if (user && user.balance !== undefined) {
            user.balance -= txData.amount;
            this.setUser(user);
        }
        return { success: true, offline: true };
    }

    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
        return { success: true };
    }
    const response = await api.post('/transactions', txData);
    return response.data;
  },

  async createPendingTransaction(txData: { senderId: string, receiverId: string, amount: number }) {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      return { transactionStatus: "Pending", transaction: { ...txData, id: 'pending-' + Date.now(), status: 'pending' } };
    }
    const response = await api.post('/transactions/create-transaction', txData);
    return response.data;
  },

  async syncOfflineTransactions() {
    const txs = this.getOfflineTransactions();
    if (txs.length === 0) return;

    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
        this.clearOfflineTransactions();
        return;
    }

    await api.post('/transactions/sync', { transactions: txs });
    this.clearOfflineTransactions();

    const user = this.getUser();
    if (user) {
        await emitter.emit({
            agentId: AGENTS.WEPAY,
            event: 'offline_lock_sync',
            payload: { timestamp: new Date().toISOString() },
            uid: user.id
        });
    }
  },

  async lockSavings(durationDays: number) {
    const until = new Date();
    until.setDate(until.getDate() + durationDays);

    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
        const user = this.getUser();
        if (user) {
            user.savingsLockedUntil = until.toISOString();
            this.setUser(user);
        }
        return { success: true, until };
    }

    const response = await api.post('/users/lock-savings', { durationDays });
    return response.data;
  },

  async getWelfarePayments() {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
        return [{ id: 'w1', schemeName: 'PM-KISAN', amount: 2000, paidAt: new Date().toISOString(), status: 'paid' }];
    }
    const response = await api.get('/welfare/payments');
    return response.data;
  },

  async checkWelfareEligibility(data: { schemeName: string, state: string, district: string, aadhaarLast4: string }) {
    const user = this.getUser() || await this.getProfile();
    
    // Emit check_welfare_eligibility event
    const result = await emitter.emit({
      agentId: AGENTS.WEPAY,
      event: 'check_welfare_eligibility',
      payload: { ...data, timestamp: new Date().toISOString() },
      uid: user.id
    });

    if (result && result.eligible !== undefined) {
      return {
        status: result.eligible ? 'Eligible' : 'Not Eligible',
        amount: result.amount || 0
      };
    }

    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
      if (data.schemeName === 'PM-KISAN' && data.state === 'Odisha') {
        return { status: 'Eligible', amount: 2000 };
      }
      if (data.schemeName === 'MGNREGA') {
        return { status: 'Eligible', amount: 3000 };
      }
      return { status: 'Not Eligible' };
    }
    const response = await api.post('/check-eligibility', {
      state: data.state,
      schemeName: data.schemeName
    });
    return {
      status: response.data.eligibilityStatus,
      amount: response.data.monthlyBenefitAmount
    };
  },

  async startOnboarding() {
    const user = this.getUser() || await this.getProfile();
    await emitter.emit({
      agentId: AGENTS.ONBOARDING,
      event: 'user_onboarding_started',
      payload: { timestamp: new Date().toISOString(), userId: user.id },
      uid: user.id
    });
  },

  async uploadDocument(schemeId: string, docType: string) {
    const user = this.getUser() || await this.getProfile();
    await emitter.emit({
      agentId: AGENTS.ONBOARDING,
      event: 'document_upload_completed',
      payload: { schemeId, docType, timestamp: new Date().toISOString() },
      uid: user.id
    });
    
    // Simulate eligibility check after upload
    this.checkEligibility(schemeId);
  },

  async checkEligibility(schemeId?: string) {
    const user = this.getUser() || await this.getProfile();
    await emitter.emit({
      agentId: AGENTS.ONBOARDING,
      event: 'eligibility_status_change',
      payload: { 
        schemeId, 
        reason: 'Data update or document verification completed',
        timestamp: new Date().toISOString() 
      },
      uid: user.id
    });
  },

  async notifyDeposit(amount: number, schemeName: string) {
    const user = this.getUser() || await this.getProfile();
    await emitter.emit({
      agentId: AGENTS.WEPAY,
      event: 'dbt_deposit_detected',
      payload: { amount, schemeName, timestamp: new Date().toISOString() },
      uid: user.id
    });
  },

  async requestVoiceAssistance(screenName: string, text?: string) {
    const user = this.getUser() || await this.getProfile();
    
    // If text is provided, use AI to check intent
    if (text) {
        if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
            if (text.toLowerCase().includes('eligibility')) {
                await this.IssueWelfareEligibilityCredential();
                return { text: 'I have verified your eligibility and issued a new credential for you.' };
            }
            return { text: "I'm here to help with your welfare schemes. How can I assist you today?" };
        }

        const aiResponse = await api.post('/ai/chat', {
            messages: [
                { role: 'system', content: 'You are a helpful assistant for rural welfare. Detect if the user wants to check their eligibility for welfare schemes. If they do, respond with exactly {"intent": "eligibility_check"}. Otherwise respond with a helpful text message.' },
                { role: 'user', content: text }
            ]
        });

        const content = aiResponse.data.text || aiResponse.data.content;
        try {
            const parsed = JSON.parse(content);
            if (parsed.intent === 'eligibility_check') {
                await this.IssueWelfareEligibilityCredential();
                return { text: 'I have verified your eligibility and issued a new credential for you.' };
            }
        } catch (e) {
            return { text: content };
        }
    }

    const result = await emitter.emit({
      agentId: AGENTS.WEPAY,
      event: 'voice_assistance_request',
      payload: { screenName, text, timestamp: new Date().toISOString() },
      uid: user.id
    });

    if (result?.intent === 'eligibility_check') {
      await this.IssueWelfareEligibilityCredential();
    }
    
    return result;
  },

  async IssueWelfareEligibilityCredential() {
    if (import.meta.env.VITE_USE_MOCK_DATA === 'true') {
        return { success: true, message: 'Mock credential issued' };
    }
    const response = await api.post('/credentials/eligibility');
    return response.data;
  },

  async syncOfflineData() {
    const user = this.getUser();
    if (!user) return; // Don't sync if no user

    await emitter.emit({
      agentId: AGENTS.WEPAY,
      event: 'offline_lock_sync',
      payload: { timestamp: new Date().toISOString() },
      uid: user.id
    });
  }
};

