import { api } from '../lib/api.ts';

export const getTransactions = async () => {
  const response = await api.get('/transactions');
  return response.data;
};

export const createTransaction = async (receiverId: string, amount: number, description?: string, locationState?: string) => {
  const response = await api.post('/transactions', { receiverId, amount, description, locationState });
  return response.data;
};

export const createTransactionPublic = async (senderId: string, receiverId: string, amount: number, locationState?: string) => {
  const response = await api.post('/transactions/create-transaction', { senderId, receiverId, amount, locationState });
  return response.data;
};

export const syncOfflineTransactions = async (transactions: any[]) => {
  const response = await api.post('/transactions/sync', { transactions });
  return response.data;
};