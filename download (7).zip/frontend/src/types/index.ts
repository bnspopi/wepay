export interface DID {
  id: string;
  controller: string;
  created: string;
}

export interface VerifiableCredential {
  id: string;
  type: string[];
  issuer: string;
  issuanceDate: string;
  credentialSubject: Record<string, any>;
  proof?: any;
  status: 'active' | 'revoked' | 'pending';
  icon?: string;
}

export interface WelfareScheme {
  id: string;
  title: string;
  name?: string; // For backward compatibility
  description: string;
  benefits: string[];
  eligibility: string[];
  category: string;
  status?: 'applied' | 'eligible' | 'not-eligible' | 'verified';
  icon?: string;
}


export interface UserProfile {
  id: string;
  did: string;
  name: string;
  email: string;
  location?: string;
  state?: string;
  district?: string;
  village?: string;
  language?: string;
  role: 'user' | 'agent';
  onboarded: boolean;
  balance?: number;
  savingsLockedUntil?: string | null;
}

export interface Transaction {
  id: string;
  senderId?: string;
  receiverId?: string;
  amount: number;
  status: 'completed' | 'pending' | 'offline';
  type: 'p2p' | 'welfare';
  description?: string;
  createdAt: string;
}

export interface WelfarePayment {
  id: string;
  schemeName: string;
  amount: number;
  status: string;
  paidAt: string;
}


export interface OnboardingStatus {
  step: 'identity' | 'verification' | 'complete';
  isProcessing: boolean;
}
