import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Download, 
  IndianRupee, 
  ShieldCheck, 
  QrCode, 
  Lock, 
  AlertCircle, 
  History, 
  RefreshCcw, 
  User,
  X
} from 'lucide-react';
import { userService } from '../services/userService';
import { getTransactions as getTxs } from '../services/transactionService';
import { getWalletBalance as getBalance, addFunds } from '../services/walletService';
import { useTranslation } from '../hooks/useTranslation';
import { useLanguage } from '../i18n/languageContext';
import { UserProfile, Transaction } from '../types';
import { emitter } from '@/agentSdk';
import { useLocation } from '../contexts/LocationContext';

export default function WalletPage() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLocking, setIsLocking] = useState(false);
  const [lockDays, setLockDays] = useState('30');
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const { t } = useTranslation();
  const { formatNumber } = useLanguage();
  const { address, error: locationError, loading: locationLoading } = useLocation();
  const navigate = useNavigate();

  const loadData = async () => {
    try {
      const [profile, txs, balData] = await Promise.all([
        userService.getProfile(),
        getTxs(),
        getBalance()
      ]);
      
      setUser(profile);
      setBalance(typeof balData === 'number' ? balData : balData.balance);
      setTransactions(txs);

      emitter.emit({
        agentId: '657cb613-4644-4143-b2a1-4d836117296d',
        event: 'voice_assistance_request',
        payload: { screen: 'WalletPage' },
        uid: profile?.id || crypto.randomUUID()
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleLockSavings = async () => {
    setIsLocking(true);
    try {
      await userService.lockSavings(parseInt(lockDays));
      await loadData();
      alert(t('lockNowMsg').replace('{days}', lockDays));
    } catch (err) {
      console.error(err);
    } finally {
      setIsLocking(false);
    }
  };

  const handleAddFunds = async () => {
    const amountStr = prompt(t('addFunds') + ':');
    if (!amountStr) return;
    
    const amount = parseFloat(amountStr);
    if (isNaN(amount) || amount <= 0) {
      alert(t('enterValidAmount'));
      return;
    }

    try {
      const res = await addFunds(amount);
      setBalance(typeof res === 'number' ? res : res.balance);
      await loadData();
      alert(t('addFundsMsg'));
    } catch (err) {
      console.error(err);
      alert(t('failedAddFunds'));
    }
  };

  const downloadEWallet = () => {
    const txSummary = transactions.slice(0, 3).map(tx => 
      `${new Date(tx.createdAt).toLocaleDateString()} - ${tx.receiverId ? t('sentTo') + ' ' + tx.receiverId : t('receivedMoney')}: ₹${tx.amount}`
    ).join('\n');

    const content = `
${t('identityCard')} - Bharat Digital Wallet
------------------------------------------
${t('fullName')}: ${user?.name}
${t('decentralizedId')}: ${user?.did}
${t('balance')}: ₹${formatNumber(balance)}
${t('didStatus')}: ${t('verified')}
${t('location')}: ${address}
${t('date')}: ${new Date().toLocaleString()}
------------------------------------------
${t('recentTransactions')}:
${txSummary || t('noTransactions')}
------------------------------------------
This is a secure decentralized identity card.
    `;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `e-wallet-${user?.name}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const isLocked = user?.savingsLockedUntil ? new Date(user.savingsLockedUntil) > new Date() : false;

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-black text-slate-800">{t('wallet')}</h1>
        <button 
          onClick={downloadEWallet}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-xl font-bold text-sm hover:bg-indigo-100 transition-all active:scale-95"
        >
          <Download className="w-4 h-4" /> {t('download_ewallet')}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Balance Card */}
        <div className="md:col-span-2">
          <div className="bg-white border-2 border-slate-100 rounded-[2.5rem] p-8 shadow-sm flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-[2rem] flex items-center justify-center">
                <IndianRupee className="w-10 h-10" />
              </div>
              <div>
                <p className="text-slate-500 font-bold uppercase tracking-widest text-sm mb-1">{t('balance')}</p>
                <h2 className="text-5xl font-black text-slate-800">₹<span data-number={balance}>{formatNumber(balance)}</span></h2>
              </div>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <button 
                onClick={() => navigate('/transaction')}
                className="flex-1 md:flex-none px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
              >
                {t('sendMoney')}
              </button>
              <button 
                onClick={handleAddFunds}
                className="flex-1 md:flex-none px-8 py-4 bg-white border-2 border-slate-100 text-slate-700 rounded-2xl font-black hover:bg-slate-50 transition-all"
              >
                {t('addFunds')}
              </button>
            </div>
          </div>
        </div>

        {/* ID Card */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-indigo-600" />
            {t('identityCard')}
          </h2>
          <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 rounded-[2rem] p-8 text-white shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-20">
                <QrCode className="w-24 h-24" />
            </div>
            <div className="flex items-center gap-6 mb-8">
              <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center border-2 border-white/30 text-3xl font-black">
                {user?.name?.[0]}
              </div>
              <div>
                <h3 className="text-2xl font-black">{user?.name}</h3>
                <p className="text-indigo-200 font-medium">{t('ruralCitizenIdentity')}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 p-4 rounded-2xl">
                <p className="text-xs font-bold text-indigo-300 uppercase tracking-widest mb-1">{t('didStatus')}</p>
                <p className="font-black">{t('verified')}</p>
              </div>
              <div className="bg-white/10 p-4 rounded-2xl">
                <p className="text-xs font-bold text-indigo-300 uppercase tracking-widest mb-1">{t('location')}</p>
                <p className="font-black truncate">{locationLoading ? t('detectingLocation') : (address || t('India'))}</p>
              </div>
            </div>
            <div className="mt-6 pt-6 border-t border-white/10 flex justify-between items-center">
                <p className="text-[10px] font-mono text-indigo-200 truncate pr-4">{user?.did}</p>
                <ShieldCheck className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* Savings Lock */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <Lock className="w-6 h-6 text-rose-600" />
            {t('savingsLock')}
          </h2>
          <div className="bg-white border-2 border-slate-100 rounded-[2rem] p-8 shadow-sm h-full flex flex-col justify-center">
            {isLocked ? (
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto">
                    <Lock className="w-8 h-8" />
                </div>
                <div>
                    <h3 className="text-xl font-black text-slate-800">{t('savingsLocked')}</h3>
                    <p className="text-slate-500 font-medium">{t('until')}: {user?.savingsLockedUntil ? new Date(user.savingsLockedUntil).toLocaleDateString() : t('tbd')}</p>
                </div>
                <div className="bg-rose-50 text-rose-700 p-4 rounded-2xl text-sm font-bold flex items-center gap-3">
                    <AlertCircle className="w-5 h-5" />
                    {t('cannotWithdrawLock')}
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <p className="text-slate-600 font-medium">{t('lockInfo')}</p>
                <div className="flex gap-4">
                    <select 
                        value={lockDays}
                        onChange={(e) => setLockDays(e.target.value)}
                        className="flex-1 px-4 py-4 rounded-2xl border-2 border-slate-100 font-bold focus:border-indigo-500 outline-none"
                    >
                        <option value="30">30 {t('days')}</option>
                        <option value="90">90 {t('days')}</option>
                        <option value="180">180 {t('days')}</option>
                        <option value="365">1 {t('year')}</option>
                    </select>
                    <button 
                        onClick={handleLockSavings}
                        disabled={isLocking}
                        className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black hover:bg-indigo-700 transition-all disabled:bg-slate-300"
                    >
                        {t('lockNow')}
                    </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <History className="w-6 h-6 text-indigo-600" />
          {t('recentTransactions')}
        </h2>
        <div className="bg-white border border-slate-200 rounded-[2.5rem] shadow-sm overflow-hidden">
          <div className="divide-y divide-slate-100">
            {transactions.length === 0 ? (
                <div className="p-12 text-center text-slate-400">
                    <RefreshCcw className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p className="font-bold">{t('noTransactions')}</p>
                </div>
            ) : (
                transactions.slice(0, 5).map((tx) => (
                    <div key={tx.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-6">
                            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${tx.status === 'offline' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700'}`}>
                                {tx.type === 'welfare' ? <ShieldCheck className="w-7 h-7" /> : <User className="w-7 h-7" />}
                            </div>
                            <div>
                                <h4 className="font-bold text-slate-800 text-lg">
                                    {
                                        tx.receiverId
                                            ? `${t('sentTo')} ${tx.receiverId}`
                                            : (tx.type === 'welfare' ? t('welfarePayout') : t('receivedMoney'))
                                    }
                                </h4>
                                <div className="flex items-center gap-3 mt-1">
                                    <p className="text-sm text-slate-500 font-medium">{new Date(tx.createdAt).toLocaleDateString()}</p>
                                    {tx.status === 'offline' && (
                                        <span className="text-[10px] font-black bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full uppercase tracking-widest">{t('offline')}</span>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="text-right">
                            <p className="text-2xl font-black text-slate-800">
                                {tx.receiverId ? '-' : '+'}₹<span data-number={tx.amount}>{formatNumber(tx.amount)}</span>
                            </p>
                            <p className={`text-xs font-bold uppercase tracking-widest ${tx.status === 'completed' ? 'text-emerald-600' : 'text-amber-600'}`}>
                                {tx.status === 'completed' ? t('completed') : t('pending')}
                            </p>
                        </div>
                    </div>
                ))
            )}
          </div>
          <button 
            onClick={() => setShowHistoryModal(true)}
            className="w-full py-6 bg-slate-50 text-slate-500 font-bold text-sm hover:bg-slate-100 transition-all"
          >
            {t('viewFullHistory')}
          </button>
        </div>
      </div>

      {/* Full History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                <History className="w-7 h-7 text-indigo-600" />
                {t('transactionDetails')}
              </h3>
              <button 
                onClick={() => setShowHistoryModal(false)}
                className="p-2 hover:bg-slate-200 rounded-full transition-colors"
              >
                <X className="w-6 h-6 text-slate-500" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex justify-between items-center p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100 transition-colors">
                  <div className="flex items-center gap-6">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${tx.status === 'offline' ? 'bg-amber-100 text-amber-700' : 'bg-white text-slate-700 shadow-sm'}`}>
                      {tx.type === 'welfare' ? <ShieldCheck className="w-7 h-7" /> : <User className="w-7 h-7" />}
                    </div>
                    <div>
                      <p className="font-black text-slate-900 text-lg">
                        {tx.receiverId 
                          ? `${t('sentTo')} ${tx.receiverId}`
                          : (tx.type === 'welfare' ? t('welfarePayout') : t('receivedMoney'))}
                      </p>
                      <p className="text-sm text-slate-500 font-medium">
                        {new Date(tx.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-black ${tx.receiverId ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {tx.receiverId ? '-' : '+'}₹<span data-number={tx.amount}>{formatNumber(tx.amount)}</span>
                    </p>
                    <p className={`text-[10px] font-bold uppercase tracking-widest ${tx.status === 'completed' ? 'text-emerald-600' : 'text-amber-600'}`}>
                      {t(tx.status)}
                    </p>
                  </div>
                </div>
              ))}
              {transactions.length === 0 && (
                <p className="text-center text-slate-500 py-12 font-medium">{t('noTransactions')}</p>
              )}
            </div>
            
            <div className="p-8 border-t border-slate-100 bg-slate-50/50">
              <button 
                onClick={() => setShowHistoryModal(false)}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-slate-800 transition-all shadow-lg"
              >
                {t('close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
