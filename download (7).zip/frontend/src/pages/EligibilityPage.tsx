import React, { useState, useRef } from 'react';
import { ShieldCheck, Search, ChevronRight, CheckCircle2, AlertCircle, Mic } from 'lucide-react';
import { welfareService } from '../services/welfareService';
import { useTranslation } from '../hooks/useTranslation';
import { useLanguage } from '../i18n/languageContext';

const STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", 
  "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", 
  "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", 
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
];

export default function EligibilityPage() {
  const [aadhaar, setAadhaar] = useState('');
  const [district, setDistrict] = useState('');
  const [state, setState] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [isListening, setIsListening] = useState(false);
  const { t } = useTranslation();
  const { language } = useLanguage();
  const recognitionRef = useRef<any>(null);

  React.useEffect(() => {
    // Agent: Voice assistance request on page load
    welfareService.requestVoiceAssistance('EligibilityPage').catch(err => {
      console.error('Failed to request voice assistance:', err);
    });
  }, []);

  const handleCheck = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!aadhaar || !state || !district) return;
    
    setLoading(true);

    try {
      const pmKisanResult = await welfareService.checkWelfareEligibility({
        schemeName: 'PM-KISAN',
        state,
        district,
        aadhaarLast4: aadhaar
      });

      const mgnregaResult = await welfareService.checkWelfareEligibility({
        schemeName: 'MGNREGA',
        state,
        district,
        aadhaarLast4: aadhaar
      });

      const eligibleSchemes = [];
      if (pmKisanResult.status === 'Eligible') {
        eligibleSchemes.push({ 
          name: 'PM-KISAN', 
          reason: t('pmKisanDesc')
        });
      }
      if (mgnregaResult.status === 'Eligible') {
        eligibleSchemes.push({ 
          name: 'MGNREGA', 
          reason: t('mgnregaDesc')
        });
      }

      setResult({
        status: eligibleSchemes.length > 0 ? 'eligible' : 'not_eligible',
        schemes: eligibleSchemes
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleVoiceAssistant = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognition) {
      alert(t('voiceNotSupported'));
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = language === 'hi' ? 'hi-IN' : (language === 'en' ? 'en-IN' : language);
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      console.log('Voice Input:', transcript);

      // Simple heuristic for state
      const detectedState = STATES.find(s => transcript.includes(s.toLowerCase()) || transcript.includes(t(s).toLowerCase()));
      if (detectedState) setState(detectedState);

      // Simple heuristic for Aadhaar (4 digits)
      const digits = transcript.match(/\d{4}/);
      if (digits) setAadhaar(digits[0]);

      // District detection - very basic for demo
      if (transcript.includes('saran') || transcript.includes('सारण')) setDistrict('Saran');
      if (transcript.includes('masrakh') || transcript.includes('मसरख')) setDistrict('Masrakh');
      if (transcript.includes('khordha') || transcript.includes('खोरधा')) setDistrict('Khordha');
      if (transcript.includes('bhubaneswar') || transcript.includes('भुवनेश्वर')) setDistrict('Bhubaneswar');

      // Check Status command
      if (transcript.includes('check') || transcript.includes('status') || transcript.includes('जाँच') || transcript.includes('स्थिति') || transcript.includes('पता')) {
        setTimeout(() => handleCheck(), 500);
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8">
      <div className="mb-8 flex justify-between items-center bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-slate-800">{t('welfareEligibility')}</h1>
          <p className="text-slate-500 font-medium">{t('checkEligibilityInfo')}</p>
        </div>
        <button 
          onClick={handleVoiceAssistant}
          className={`p-5 rounded-3xl shadow-lg transition-all active:scale-95 ${isListening ? 'bg-rose-500 animate-pulse text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
        >
          <Mic className="w-7 h-7" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-xl space-y-6">
            <h2 className="font-black text-xl flex items-center gap-3 text-slate-900">
              <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                <Search className="w-5 h-5" />
              </div>
              {t('checkEligibility')}
            </h2>
            <form onSubmit={handleCheck} className="space-y-5">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">{t('aadhaarLast4')}</label>
                <input 
                  type="text" 
                  maxLength={4}
                  value={aadhaar}
                  onChange={(e) => setAadhaar(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-5 py-4 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 outline-none transition-all font-bold text-lg"
                  placeholder="e.g. 1234"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">{t('state')}</label>
                <select 
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-5 py-4 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 outline-none transition-all font-bold"
                  required
                >
                  <option value="">{t('selectState')}</option>
                  {STATES.map(s => (
                    <option key={s} value={s}>{t(s)}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">{t('district')}</label>
                <input 
                  type="text" 
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-5 py-4 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 outline-none transition-all font-bold"
                  placeholder={t('enterDistrict')}
                  required
                />
              </div>
              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:bg-slate-200 disabled:shadow-none"
              >
                {loading ? t('checking') : t('checkStatus')}
              </button>
            </form>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          {!result && !loading && (
            <div className="bg-indigo-50 border border-indigo-100 p-10 rounded-[2.5rem] text-center space-y-4">
              <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto shadow-sm">
                <ShieldCheck className="w-10 h-10 text-indigo-500" />
              </div>
              <h3 className="font-black text-slate-900 text-2xl">{t('verificationReady')}</h3>
              <p className="text-slate-600 font-medium leading-relaxed">{t('enterDetailsInfo')}</p>
            </div>
          )}

          {loading && (
            <div className="bg-white border border-slate-100 p-16 rounded-[2.5rem] text-center shadow-sm">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto mb-6"></div>
              <p className="text-slate-600 font-bold text-lg">{t('verifyingIdentity')}</p>
            </div>
          )}

          {result && (
            <div className="space-y-6">
              {result.status === 'eligible' ? (
                <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-[2.5rem] flex items-start gap-5 shadow-sm">
                  <div className="p-3 bg-white rounded-2xl shadow-sm">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 flex-shrink-0" />
                  </div>
                  <div>
                    <h3 className="font-black text-emerald-900 text-xl">{t('congratulations')}</h3>
                    <p className="text-emerald-700 font-medium mt-1">{t('eligibleSchemesInfo')}</p>
                  </div>
                </div>
              ) : (
                <div className="bg-rose-50 border border-rose-100 p-8 rounded-[2.5rem] flex items-start gap-5 shadow-sm">
                  <div className="p-3 bg-white rounded-2xl shadow-sm">
                    <AlertCircle className="w-8 h-8 text-rose-600 flex-shrink-0" />
                  </div>
                  <div>
                    <h3 className="font-black text-rose-900 text-xl">{t('notEligible')}</h3>
                    <p className="text-rose-700 font-medium mt-1">{t('noSchemesFound')}</p>
                  </div>
                </div>
              )}

              <div className="grid gap-4">
                {result.schemes.map((scheme: any, idx: number) => (
                  <div key={idx} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex justify-between items-center group hover:border-indigo-300 hover:shadow-md transition-all">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 border border-indigo-100 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                        <ShieldCheck className="w-8 h-8" />
                      </div>
                      <div>
                        <div className="flex items-center gap-3">
                          <h4 className="font-black text-slate-800 text-lg">{t(scheme.name)}</h4>
                          <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black px-2.5 py-1 rounded-lg uppercase tracking-wider">{t('eligible')}</span>
                        </div>
                        <p className="text-slate-500 font-medium mt-1">{t(scheme.reason)}</p>
                      </div>
                    </div>
                    <button className="p-3 rounded-xl bg-slate-50 text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-all">
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}