import React, { useState } from 'react';
import { Users, UserPlus, FileSearch, ShieldCheck, MapPin, Search, ChevronRight, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { welfareService } from '../services/welfareService';
import { useLanguage } from '../i18n/languageContext';

const AgentPortal: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'users' | 'requests'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const { t } = useLanguage();

  const mockUsers = [
    { id: '1', name: 'Ramesh Singh', location: 'Saran, Bihar', status: 'verified', did: 'did:key:z6Mkha...' },
    { id: '2', name: 'Sita Devi', location: 'Saran, Bihar', status: 'pending', did: 'did:key:z6Mkja...' },
    { id: '3', name: 'Mohan Lal', location: 'Saran, Bihar', status: 'verified', did: 'did:key:z6Mkpa...' },
  ];

  const pendingRequests = [
    { id: 'req-001', user: 'Sita Devi', document: 'Land Records', scheme: 'PM-KISAN', date: '2024-02-20' },
    { id: 'req-002', user: 'Amit Sahni', document: 'Job Card', scheme: 'MGNREGA', date: '2024-02-22' },
  ];

  const handleOnboard = async () => {
    await welfareService.startOnboarding();
    alert(t('onboardingInitiated'));
  };

  const handleVerify = (id: string) => {
    welfareService.checkEligibility();
    alert(t('documentVerified'));
  };

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{t('agentPortal')}</h1>
          <p className="text-slate-500">{t('authorizedPersonnel')}: Agent #4201</p>
        </div>
        <button 
          onClick={handleOnboard}
          className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-indigo-200 flex items-center gap-2 hover:bg-indigo-700 transition-all active:scale-95"
        >
          <UserPlus className="w-5 h-5" />
          {t('onboardNewUser')}
        </button>
      </header>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('users')}
          className={`px-8 py-4 font-bold text-sm transition-all relative ${
            activeTab === 'users' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          {t('registeredUsers')}
          {activeTab === 'users' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full"></div>}
        </button>
        <button 
          onClick={() => setActiveTab('requests')}
          className={`px-8 py-4 font-bold text-sm transition-all relative ${
            activeTab === 'requests' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          {t('pendingVerifications')}
          <span className="ml-2 bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
            {pendingRequests.length}
          </span>
          {activeTab === 'requests' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full"></div>}
        </button>
      </div>

      <div className="space-y-6">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder={activeTab === 'users' ? t('searchUsers') : t('searchRequests')}
            className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {activeTab === 'users' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockUsers.filter(u => u.name.toLowerCase().includes(searchTerm.toLowerCase())).map(user => (
              <div key={user.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between group hover:border-indigo-200 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-500 font-bold group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                    {user.name[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{user.name}</h3>
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {t(user.location)}</span>
                      <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> {t(user.status)}</span>
                    </div>
                  </div>
                </div>
                <button className="p-2 text-slate-300 hover:text-indigo-600 transition-colors">
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">{t('userScheme')}</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">{t('document')}</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">{t('date')}</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">{t('action')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pendingRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
                          <AlertCircle className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800">{req.user}</p>
                          <p className="text-xs text-indigo-600 font-medium">{t(req.scheme)}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6 text-sm text-slate-600">
                      <div className="flex items-center gap-2">
                        <FileSearch className="w-4 h-4 text-slate-400" />
                        {t(req.document)}
                      </div>
                    </td>
                    <td className="px-6 py-6 text-sm text-slate-400">{req.date}</td>
                    <td className="px-6 py-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={() => handleVerify(req.id)}
                          className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100 transition-colors"
                        >
                          <CheckCircle2 className="w-5 h-5" />
                        </button>
                        <button className="p-2 bg-rose-50 text-rose-600 rounded-lg hover:bg-rose-100 transition-colors">
                          <XCircle className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Agent Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-8 rounded-[2rem] text-white shadow-xl shadow-indigo-200">
          <p className="text-indigo-100 font-medium mb-1">{t('totalUsersOnboarded')}</p>
          <h2 className="text-4xl font-black" data-number="128">128</h2>
          <div className="mt-6 flex items-center gap-2 text-indigo-100 text-sm">
            <Users className="w-4 h-4" />
            <span>+<span data-number="12">12</span> {t('thisWeek')}</span>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
          <p className="text-slate-400 font-medium mb-1">{t('verificationScore')}</p>
          <h2 className="text-4xl font-black text-slate-800" data-number="99.2">99.2%</h2>
          <div className="mt-6 flex items-center gap-2 text-emerald-600 text-sm font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>{t('topTierAgent')}</span>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
          <p className="text-slate-400 font-medium mb-1">{t('avgOnboardingTime')}</p>
          <h2 className="text-4xl font-black text-slate-800" data-number="14">14 {t('min')}</h2>
          <div className="mt-6 flex items-center gap-2 text-indigo-600 text-sm font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>{t('certifiedValidator')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentPortal;
