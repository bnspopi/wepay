import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, User, MapPin, Fingerprint, ChevronRight, CheckCircle2, Loader2, Languages, Home } from 'lucide-react';
import { welfareService } from '../services/welfareService';
import { emitter } from '@/agentSdk';
import { useLanguage } from '../i18n/languageContext';

const OnboardingPage: React.FC = () => {
  const navigate = useNavigate();
  const { t, language: currentLang, setLanguage, location: detectedState } = useLanguage();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    state: '',
    district: '',
    village: '',
    language: currentLang || 'hi',
    aadhaar: ''
  });

  const INDIAN_STATES = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", 
    "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", 
    "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", 
    "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
  ];

  const LANGUAGES = [
    { code: 'en', name: 'English' },
    { code: 'hi', name: 'Hindi (हिंदी)' },
    { code: 'bn', name: 'Bengali (বাংলা)' },
    { code: 'te', name: 'Telugu (తెలుగు)' },
    { code: 'mr', name: 'Marathi (मराठी)' },
    { code: 'ta', name: 'Tamil (தமிழ்)' },
    { code: 'gu', name: 'Gujarati (ગુજરાતી)' },
    { code: 'kn', name: 'Kannada (ಕನ್ನಡ)' },
    { code: 'or', name: 'Odia (ଓଡ଼ିଆ)' },
    { code: 'pa', name: 'Punjabi (ਪੰਜਾਬੀ)' },
    { code: 'ml', name: 'Malayalam (മലയാളം)' },
    { code: 'as', name: 'Assamese (অসমীয়া)' }
  ];

  useEffect(() => {
    if (detectedState !== "India" && !formData.state) {
      setFormData(prev => ({ ...prev, state: detectedState }));
    }
  }, [detectedState]);

  useEffect(() => {
    // Agent: User onboarding started
    welfareService.startOnboarding().catch(err => {
      console.error('Failed to start onboarding:', err);
    });

    // Agent: Voice assistance request on page load
    welfareService.requestVoiceAssistance('OnboardingPage').catch(err => {
      console.error('Failed to request voice assistance:', err);
    });
  }, []);

  const handleNext = () => {
    if (step < 3) {
      const nextStep = step + 1;
      setStep(nextStep);
      
      // Agent: Voice assistance request for new step
      welfareService.requestVoiceAssistance('OnboardingPage', `Step ${nextStep}`);
    } else {
      completeOnboarding();
    }
  };

  const completeOnboarding = async () => {
    setLoading(true);
    try {
      // Generate a mock DID for now (in real world this is done locally)
      const mockDid = 'did:key:z6Mkha' + Math.random().toString(36).substring(7);
      
      // Update global language if changed in form
      if (formData.language !== currentLang) {
        setLanguage(formData.language);
      }

      await welfareService.updateProfile({
        name: formData.name || 'New User',
        state: formData.state,
        district: formData.district,
        village: formData.village,
        language: formData.language,
        location: `${formData.village}, ${formData.district}, ${formData.state}`,
        did: mockDid,
        onboarded: true
      });

      await welfareService.startOnboarding();
      navigate('/');
    } catch (error) {
      console.error('Onboarding failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md space-y-12">
        <div className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-indigo-200">
            <Shield className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black text-slate-900">{t('createDid')}</h1>
          <p className="text-slate-500">{t('secureIdentity')}</p>
        </div>

        {/* Stepper */}
        <div className="flex justify-between relative max-w-[200px] mx-auto">
          {[1, 2, 3].map((s) => (
            <div 
              key={s} 
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all z-10 ${
                step >= s ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-400'
              }`}
            >
              {step > s ? <CheckCircle2 className="w-5 h-5" /> : s}
            </div>
          ))}
          <div className="absolute top-5 left-0 right-0 h-0.5 bg-slate-100 -z-0"></div>
          <div 
            className="absolute top-5 left-0 h-0.5 bg-indigo-600 transition-all duration-500"
            style={{ width: `${(step - 1) * 50}%` }}
          ></div>
        </div>

        {/* Step Content */}
        <div className="bg-slate-50 rounded-[2.5rem] p-8 min-h-[400px] flex flex-col justify-center border border-slate-100">
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-2">
                  <User className="w-3 h-3" /> {t('fullName')}
                </label>
                <input 
                  type="text" 
                  className="w-full bg-white border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-600 shadow-sm"
                  placeholder={t('fullNamePlaceholder')}
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-2">
                    <MapPin className="w-3 h-3" /> {t('state')}
                  </label>
                  <select 
                    className="w-full bg-white border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-600 shadow-sm appearance-none"
                    value={formData.state}
                    onChange={(e) => setFormData({...formData, state: e.target.value})}
                  >
                    <option value="">{t('selectState')}</option>
                    {INDIAN_STATES.map(s => <option key={s} value={s}>{t(s)}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-2">
                    <MapPin className="w-3 h-3" /> {t('district')}
                  </label>
                  <input 
                    type="text" 
                    className="w-full bg-white border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-600 shadow-sm"
                    placeholder={t('districtPlaceholder')}
                    value={formData.district}
                    onChange={(e) => setFormData({...formData, district: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-2">
                  <Home className="w-3 h-3" /> {t('village')}
                </label>
                <input 
                  type="text" 
                  className="w-full bg-white border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-600 shadow-sm"
                  placeholder={t('villagePlaceholder')}
                  value={formData.village}
                  onChange={(e) => setFormData({...formData, village: e.target.value})}
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-2">
                  <Languages className="w-3 h-3" /> {t('preferredLanguage')}
                </label>
                <select 
                  className="w-full bg-white border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-600 shadow-sm appearance-none"
                  value={formData.language}
                  onChange={(e) => setFormData({...formData, language: e.target.value})}
                >
                  {LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.name}</option>)}
                </select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="text-center space-y-4">
                <div className="mx-auto w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-indigo-600 border border-slate-100 shadow-sm">
                  <Fingerprint className="w-10 h-10" />
                </div>
                <h3 className="font-bold text-slate-800">{t('identityVerification')}</h3>
                <p className="text-sm text-slate-500">{t('aadhaarVerificationDesc')}</p>
              </div>
              <input 
                type="text" 
                className="w-full bg-white border-none rounded-2xl p-4 focus:ring-2 focus:ring-indigo-600 shadow-sm text-center tracking-widest font-mono"
                placeholder="XXXX-XXXX-XXXX"
                value={formData.aadhaar}
                onChange={(e) => setFormData({...formData, aadhaar: e.target.value})}
              />
            </div>
          )}

          {step === 3 && (
            <div className="text-center space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="mx-auto w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center text-emerald-600">
                <Shield className="w-10 h-10" />
              </div>
              <h3 className="font-bold text-slate-800">{t('finalizeDid')}</h3>
              <p className="text-sm text-slate-500">
                {t('didGenerationDesc')}
              </p>
              <div className="p-4 bg-white rounded-2xl border border-slate-200 text-[10px] font-mono text-slate-400 break-all">
                did:key:z6MkhaXgBZDnzR6q7WPrRMDG5Y7A9pG8...
              </div>
            </div>
          )}
        </div>

        <button 
          onClick={handleNext}
          disabled={loading}
          className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
        >
          {loading ? (
            <Loader2 className="w-6 h-6 animate-spin" />
          ) : (
            <>
              {step === 3 ? t('generateDid') : t('continue')}
              <ChevronRight className="w-5 h-5" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default OnboardingPage;
