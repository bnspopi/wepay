import React, { useState, useEffect } from 'react';
import { Send, User, IndianRupee, WifiOff, Wifi, AlertTriangle, CheckCircle2, History, X, ShieldAlert } from 'lucide-react';
import { createTransaction } from '../services/transactionService';
import { userService } from '../services/userService';
import { welfareService } from '../services/welfareService';
import { useTranslation } from '../hooks/useTranslation';
import { useLanguage } from '../i18n/languageContext';
import { useLocation } from '../contexts/LocationContext';

export default function TransactionPage() {
  const [receiverId, setReceiverId] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'offline-success' | 'error' | 'flagged'>('idle');
  const [lastTransaction, setLastTransaction] = useState<{ amount: string, receiver: string, security?: any } | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const isOnline = navigator.onLine;
  const { t } = useTranslation();
  const { formatNumber } = useLanguage();
  const { state: locationState } = useLocation();

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const allUsers = await userService.getAllUsers();
        setUsers(allUsers);
      } catch (err) {
        console.error('Failed to load users:', err);
      }
    };
    loadUsers();

    // Agent: Voice assistance request on page load
    welfareService.requestVoiceAssistance('TransactionPage').catch(err => {
      console.error('Failed to request voice assistance:', err);
    });
  }, []);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!receiverId || !amount) return;
    
    setLoading(true);
    setStatus('idle');
    setErrorMessage('');
    try {
      const currentAmount = amount;
      let finalReceiverId = receiverId;

      // Map demo user IDs to their internal DID identities automatically
      const targetUser = users.find(u => u.id === receiverId || u.did === receiverId || u.name === receiverId);
      
      if (targetUser) {
        // Map to internal identity if found in live users list
        finalReceiverId = targetUser.did || targetUser.id;
      } else {
        // If not found in local list, we still allow it to be sent as is to the backend
        // This ensures the backend can validate it against the full user database
        finalReceiverId = receiverId;
      }

      const response = await createTransaction(finalReceiverId, parseFloat(amount), 'Transfer', locationState || undefined);

      setLastTransaction({ 
        amount: currentAmount, 
        receiver: targetUser ? targetUser.name : finalReceiverId,
        security: response.security
      });

      if (response.status === 'flagged') {
        setStatus('flagged');
      } else {
        setStatus('success');
      }
      
      setReceiverId('');
      setAmount('');
    } catch (err: any) {
      setStatus('error');
      setErrorMessage(err.response?.data?.message || err.message || t('paymentFailed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-black text-slate-800">{t('sendMoney')}</h1>
        <div className="flex items-center gap-2 mt-3">
          {isOnline ? (
            <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full uppercase tracking-wider">
              <Wifi className="w-3.5 h-3.5" /> {t('onlineMode')}
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-[10px] font-bold text-amber-600 bg-amber-50 px-3 py-1 rounded-full uppercase tracking-wider">
              <WifiOff className="w-3.5 h-3.5" /> {t('offlineMode')}
            </span>
          )}
        </div>
      </div>

      <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-2xl space-y-8">
        <form onSubmit={handleSend} className="space-y-8">
          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-600 ml-1">{t('receiverIdOrPhone')}</label>
            <div className="relative">
              <User className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400" />
              <input 
                type="text" 
                value={receiverId}
                onChange={(e) => setReceiverId(e.target.value)}
                className="w-full pl-14 pr-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 outline-none text-xl font-bold transition-all placeholder:text-slate-300"
                placeholder="demo-user-1"
                required
              />
            </div>
            <p className="text-xs text-slate-400 ml-1 font-medium">Enter DID in format demo-user-1022</p>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-600 ml-1">{t('amount')}</label>
            <div className="relative">
              <IndianRupee className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400" />
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-14 pr-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 outline-none text-4xl font-black transition-all text-slate-800"
                placeholder="0"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading || !receiverId || !amount}
            className="w-full bg-indigo-600 text-white py-6 rounded-[1.5rem] font-black text-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-95 disabled:bg-slate-200 disabled:shadow-none flex items-center justify-center gap-3"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
            ) : (
              <>
                <Send className="w-7 h-7" />
                {isOnline ? t('sendInstantly') : t('saveOffline')}
              </>
            )}
          </button>
        </form>

        {(status === 'success' || status === 'offline-success' || status === 'flagged') && lastTransaction && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="bg-white w-full max-w-md rounded-[3rem] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
              <div className={`${status === 'flagged' ? 'bg-amber-600' : 'bg-emerald-600'} p-10 text-center text-white relative`}>
                <button onClick={() => setStatus('idle')} className="absolute top-6 right-6 text-white/60 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
                <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-white/30">
                  {status === 'flagged' ? <ShieldAlert className="w-14 h-14 text-white" /> : <CheckCircle2 className="w-14 h-14 text-white" />}
                </div>
                <h2 className="text-4xl font-black mb-1">₹<span data-number={parseFloat(lastTransaction.amount)}>{formatNumber(parseFloat(lastTransaction.amount))}</span></h2>
                <p className="text-white font-black text-lg">
                  {status === 'flagged' ? t('transactionFlagged') : (status === 'success' ? t('paymentSuccessful') : t('savedOffline'))}
                </p>
              </div>
              
              <div className="p-8 text-center space-y-6">
                <div>
                  <p className="text-slate-400 font-black uppercase tracking-widest text-xs mb-2">{t('sentTo')}</p>
                  <h3 className="text-3xl font-black text-slate-800">{lastTransaction.receiver}</h3>
                </div>
                
                {status === 'flagged' && lastTransaction.security?.alerts && (
                  <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl text-left">
                    <p className="text-amber-800 font-black text-xs uppercase mb-2 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4" /> Security Alerts:
                    </p>
                    <ul className="space-y-1">
                      {lastTransaction.security.alerts.map((alert: string, idx: number) => (
                        <li key={idx} className="text-amber-700 text-xs font-bold leading-tight flex items-start gap-2">
                          <span className="w-1 h-1 rounded-full bg-amber-400 mt-1.5 flex-shrink-0"></span>
                          {alert}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="space-y-6">
                  <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100">
                    <p className="text-emerald-700 font-black text-sm leading-relaxed">
                      {status === 'flagged' ? t('transactionFlaggedInfo') : `${t('sent')} ₹${formatNumber(parseFloat(lastTransaction.amount))} ${t('to')} ${lastTransaction.receiver}`}
                    </p>
                    {lastTransaction.security?.riskScore !== undefined && (
                      <p className="text-slate-400 text-[10px] font-black mt-2 uppercase tracking-widest">
                        AI Risk Score: {(lastTransaction.security.riskScore * 100).toFixed(1)}%
                      </p>
                    )}
                  </div>

                  <div className="text-left space-y-2 pt-4 border-t border-slate-100">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400 font-bold uppercase">{t('upiRefId')}</span>
                      <span className="text-slate-900 font-black">TXN{Math.floor(Date.now() / 1000)}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400 font-bold uppercase">{t('status')}</span>
                      <span className={`${status === 'flagged' ? 'text-amber-600' : 'text-emerald-600'} font-black uppercase`}>
                        {status === 'flagged' ? t('flagged') : t('completed')}
                      </span>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => setStatus('idle')}
                    className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-xl hover:bg-slate-800 transition-all shadow-lg active:scale-95"
                  >
                    {t('done')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="mt-8 bg-rose-50 border border-rose-100 p-8 rounded-3xl flex items-start gap-5 animate-in fade-in slide-in-from-bottom-6">
            <div className="p-3 bg-white rounded-2xl shadow-sm">
              <AlertTriangle className="w-8 h-8 text-rose-600" />
            </div>
            <div>
              <h3 className="font-black text-rose-900 text-lg">{t('paymentFailed')}</h3>
              <p className="text-rose-700 font-medium mt-1">{errorMessage}</p>
            </div>
          </div>
        )}
      </div>

      <div className="mt-10 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
        <div className="flex items-center gap-3 text-slate-900 font-black text-xl">
          <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
            <History className="w-6 h-6" />
          </div>
          {t('recentTips')}
        </div>
        <ul className="space-y-4">
          <li className="flex gap-4 items-start">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 flex-shrink-0"></div>
            <p className="text-slate-600 font-medium">{t('tip1')}</p>
          </li>
          <li className="flex gap-4 items-start">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 flex-shrink-0"></div>
            <p className="text-slate-600 font-medium">{t('tip2')}</p>
          </li>
          <li className="flex gap-4 items-start">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 flex-shrink-0"></div>
            <p className="text-slate-600 font-medium">{t('tip3')}</p>
          </li>
        </ul>
      </div>
    </div>
  );
}