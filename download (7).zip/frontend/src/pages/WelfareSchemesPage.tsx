import React, { useState, useEffect } from 'react';
import { Search, Filter, ArrowUpRight, CheckCircle2, AlertCircle, Clock, Upload, ChevronRight, ShieldCheck } from 'lucide-react';
import { welfareService } from '../services/welfareService';
import { WelfareScheme } from '../types';
import { emitter } from '@/agentSdk';
import { useTranslation } from '../hooks/useTranslation';

const WelfareSchemesPage: React.FC = () => {
  const [schemes, setSchemes] = useState<WelfareScheme[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'Agriculture' | 'Employment' | 'Financial' | string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const { t } = useTranslation();

  useEffect(() => {
    const fetchSchemes = async () => {
      try {
        const data = await welfareService.getSchemes();
        setSchemes(data);

        // Agent: Voice assistance request on page load
        emitter.emit({
          agentId: '657cb613-4644-4143-b2a1-4d836117296d',
          event: 'voice_assistance_request',
          payload: { screen: 'DashboardPage' },
          uid: crypto.randomUUID()
        });
      } catch (error) {
        console.error('Error fetching schemes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSchemes();
  }, []);

  const filteredSchemes = schemes.filter(s => 
    (filter === 'all' || s.category === filter) &&
    (s.title || s.name || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: WelfareScheme['status']) => {
    if (!status || status === 'eligible') return (
      <span className="flex items-center gap-1.5 px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold">
        <ArrowUpRight className="w-3.5 h-3.5" /> {t('eligible')}
      </span>
    );

    switch (status) {
      case 'verified':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" /> {t('verified')}
          </span>
        );
      case 'applied':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">
            <Clock className="w-3.5 h-3.5" /> {t('pending')}
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-500 rounded-full text-xs font-bold">
            <AlertCircle className="w-3.5 h-3.5" /> {t('notEligible')}
          </span>
        );
    }
  };



  const handleApply = async (scheme: WelfareScheme) => {
    await welfareService.uploadDocument(scheme.id, 'Identity Proof');
    
    // Agent: Document upload completed event
    emitter.emit({
      agentId: '6fe83d52-563f-4ba8-865b-e494f927549d',
      event: 'document_upload_completed',
      payload: { schemeId: scheme.id, schemeName: scheme.title || scheme.name, documentType: 'Identity Proof' },
      uid: crypto.randomUUID()
    });

    alert(t('applicationSuccess'));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <header className="space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{t('welfare')}</h1>
          <p className="text-slate-500">{t('findApplyBenefits')}</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text" 
              placeholder={t('searchSchemesPlaceholder')}
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            {(['all', 'Agriculture', 'Employment', 'Financial'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-3 rounded-2xl font-semibold transition-all ${
                  filter === cat 
                    ? 'bg-slate-900 text-white shadow-md' 
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {t(cat)}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label={t('totalSchemes')} value={schemes.length} color="indigo" />
        <StatCard label={t('eligible')} value={schemes.filter(s => !s.status || s.status === 'eligible').length} color="emerald" />
        <StatCard label={t('pending')} value={schemes.filter(s => s.status === 'applied').length} color="amber" />
        <StatCard label={t('activeBenefits')} value={schemes.filter(s => s.status === 'verified').length} color="blue" />
      </div>

      {/* Schemes Grid */}
      <div className="grid grid-cols-1 gap-6">
        {filteredSchemes.map((scheme) => (
          <div 
            key={scheme.id} 
            className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm hover:shadow-lg transition-all group"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
              <div className="space-y-4 flex-1">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                    <ShieldCheck className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-800">{t(scheme.title || scheme.name || '')}</h3>
                    {getStatusBadge(scheme.status)}
                  </div>
                </div>
                
                <p className="text-slate-500 text-sm max-w-2xl leading-relaxed">
                  {t(scheme.id === '1' ? 'pmKisanDesc' : scheme.id === '2' ? 'mgnregaDesc' : 'dbtWelfareDesc')}
                </p>

                <div className="flex flex-wrap gap-2">
                  {scheme.id === '1' && (
                    <>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('smallFarmers')}</span>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('validLandRecords')}</span>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('aadharLinkedBank')}</span>
                    </>
                  )}
                  {scheme.id === '2' && (
                    <>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('mgnregaEligibility1')}</span>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('mgnregaEligibility2')}</span>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('mgnregaEligibility3')}</span>
                    </>
                  )}
                  {scheme.id === '3' && (
                    <>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('dbtEligibility1')}</span>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('dbtEligibility2')}</span>
                      <span className="bg-slate-50 text-slate-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-100">{t('dbtEligibility3')}</span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex flex-col md:flex-row items-center gap-6 lg:border-l lg:border-slate-100 lg:pl-8 min-w-[240px]">
                <div className="w-full md:flex-1 space-y-1">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('benefit')}</p>
                  <p className="text-lg font-black text-indigo-700">
                    {scheme.id === '1' ? t('annualSupport6000') : scheme.id === '2' ? t('guaranteedWageEmployment') : t('eliminationMiddleman')}
                  </p>
                </div>
                {!scheme.status || scheme.status === 'eligible' ? (
                  <button 
                    onClick={() => handleApply(scheme)}
                    className="w-full md:w-auto px-8 py-4 bg-indigo-600 text-white font-black rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center gap-2 group-hover:scale-105 active:scale-95"
                  >
                    {t('applyNow')}
                    <ChevronRight className="w-5 h-5" />
                  </button>
                ) : (
                  <button className="w-full md:w-auto px-8 py-4 bg-slate-100 text-slate-400 font-black rounded-2xl cursor-not-allowed">
                    {scheme.status === 'verified' ? t('active') : t('pendingReview')}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  const colors: any = {
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-100',
    emerald: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    amber: 'bg-amber-50 text-amber-700 border-amber-100',
    blue: 'bg-blue-50 text-blue-700 border-blue-100',
  };

  return (
    <div className={`p-4 rounded-2xl border ${colors[color]} shadow-sm`}>
      <p className="text-[10px] uppercase font-bold opacity-70 mb-1">{label}</p>
      <p className="text-2xl font-black" data-number={value}>{value}</p>
    </div>
  );
}

export default WelfareSchemesPage;
