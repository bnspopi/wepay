import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  History, 
  ArrowLeft,
  ArrowUpRight,
  ArrowDownLeft,
  Search,
  Filter
} from 'lucide-react';
import { getTransactions } from '../services/transactionService';
import { authService } from '../services/authService';
import { userService } from '../services/userService';
import { useTranslation } from '../hooks/useTranslation';
import { useLanguage } from '../i18n/languageContext';

export default function TransactionHistoryPage() {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { formatNumber } = useLanguage();

  useEffect(() => {
    const loadData = async () => {
      try {
        const [me, txs, allUsers] = await Promise.all([
          authService.getMe(),
          getTransactions(),
          userService.getAllUsers()
        ]);
        setCurrentUser(me);
        setTransactions(txs);
        setUsers(allUsers);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const filteredTxs = transactions.filter(tx => {
    const otherPartyId = tx.senderId === currentUser?.id ? tx.receiverId : tx.senderId;
    const otherPartyName = users.find(u => u.id === otherPartyId)?.name || 'User';
    return otherPartyName.toLowerCase().includes(search.toLowerCase()) || 
           tx.amount.toString().includes(search);
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 space-y-6">
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate(-1)}
          className="p-3 bg-white border border-slate-200 rounded-2xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm active:scale-95"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-black text-slate-900">{t('recentTransactions')}</h1>
      </div>

      <div className="relative">
        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400" />
        <input 
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full pl-14 pr-6 py-5 bg-white border-2 border-slate-100 rounded-3xl focus:border-indigo-500 focus:ring-0 outline-none font-bold text-lg shadow-sm transition-all"
        />
      </div>

      <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="divide-y divide-slate-100">
          {filteredTxs.length > 0 ? (
            filteredTxs.map((tx) => {
              const isSender = tx.senderId === currentUser?.id;
              const otherParty = users.find(u => u.id === (isSender ? tx.receiverId : tx.senderId));
              
              return (
                <div key={tx.id} className="p-8 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-6">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm ${isSender ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                      {isSender ? <ArrowUpRight className="w-8 h-8" /> : <ArrowDownLeft className="w-8 h-8" />}
                    </div>
                    <div>
                      <p className="font-black text-slate-900 text-lg">
                        {isSender ? `${t('sentTo')}: ${otherParty?.name || 'User'}` : `${t('receivedFrom')}: ${otherParty?.name || 'User'}`}
                      </p>
                      <p className="text-sm text-slate-500 font-medium">
                        {new Date(tx.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-black ${isSender ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {isSender ? '-' : '+'} ₹<span data-number={tx.amount}>{formatNumber(tx.amount)}</span>
                    </p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{t(tx.status)}</p>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-20 text-center text-slate-400">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <History className="w-10 h-10 opacity-20" />
              </div>
              <p className="font-black text-xl">{t('noTransactions')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

