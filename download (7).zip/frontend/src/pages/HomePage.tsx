import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Wallet, 
  Send, 
  ShieldCheck, 
  Search, 
  RefreshCcw, 
  Mic, 
  Bell,
  Wifi,
  WifiOff,
  MapPin,
  QrCode,
  UserCheck,
  Users as UsersIcon,
  ChevronDown,
  Globe,
  Download,
  X,
  LayoutDashboard
} from 'lucide-react';
import { userService } from '../services/userService';
import { authService } from '../services/authService';
import { createTransaction, getTransactions as getTxs } from '../services/transactionService';
import { UserProfile } from '../types';
import { emitter } from '@/agentSdk';
import { useLanguage } from "../i18n/languageContext";
import { useLocation } from '../contexts/LocationContext';

const MORE_LANGUAGES = [
  { name: "Bengali", code: "bn" },
  { name: "Telugu", code: "te" },
  { name: "Marathi", code: "mr" },
  { name: "Tamil", code: "ta" },
  { name: "Urdu", code: "ur" },
  { name: "Gujarati", code: "gu" },
  { name: "Kannada", code: "kn" },
  { name: "Odia", code: "or" },
  { name: "Malayalam", code: "ml" },
  { name: "Punjabi", code: "pa" },
  { name: "Assamese", code: "as" },
  { name: "Maithili", code: "mai" },
  { name: "Santali", code: "sat" },
  { name: "Kashmiri", code: "ks" },
  { name: "Nepali", code: "ne" },
  { name: "Konkani", code: "kok" },
  { name: "Manipuri", code: "mni" },
  { name: "Bodo", code: "brx" },
  { name: "Dogri", code: "doi" },
  { name: "Sindhi", code: "sd" },
  { name: "Sanskrit", code: "sa" },
];

export default function HomePage() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [balance, setBalance] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [users, setUsers] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [isMoreLangsOpen, setIsMoreLangsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  const { language, setLanguage, setIsManual, isManual, t, formatNumber } = useLanguage();
  const { address, state, error: locationError, loading: locationLoading } = useLocation();
  const navigate = useNavigate();
  const recognitionRef = useRef<any>(null);

  const loadData = async () => {
    try {
      const userData = await authService.getMe();
      setUser(userData);
      setBalance(userData.balance || 0);

      const allUsers = await userService.getAllUsers();
      setUsers(allUsers);

      const history = await getTxs();
      setTransactions(history.slice(0, 5));

      // Mock notifications
      setNotifications([
        { id: 1, title: t('paymentReceived'), message: '₹500 received from Sita', time: '2m ago' },
        { id: 2, title: t('schemeUpdate'), message: 'Your PM-Kisan status is now Active', time: '1h ago' }
      ]);

      emitter.emit({
        agentId: '657cb613-4644-4143-b2a1-4d836117296d',
        event: 'voice_assistance_request',
        payload: { screen: 'HomePage' },
        uid: userData?.id || crypto.randomUUID()
      });
    } catch (error) {
      console.error('Failed to load data:', error);
    }
  };

  useEffect(() => {
    loadData();

    const handleConnection = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleConnection);
    window.addEventListener('offline', handleConnection);

    return () => {
      window.removeEventListener('online', handleConnection);
      window.removeEventListener('offline', handleConnection);
    };
  }, []);

  const handleSpeech = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognition) {
      alert(t('voiceNotSupported'));
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = language === 'hi' ? 'hi-IN' : (language === 'en' ? 'en-IN' : language);
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      console.log('Voice Command:', transcript);

      if (transcript.includes('wallet') || transcript.includes('बैलेंस')) {
        navigate('/wallet');
      } else if (transcript.includes('send') || transcript.includes('पैसे')) {
        navigate('/transaction');
      } else if (transcript.includes('eligibility') || transcript.includes('पात्रता')) {
        navigate('/eligibility');
      } else if (transcript.includes('welfare') || transcript.includes('कल्याण')) {
        navigate('/welfare');
      } else if (transcript.includes('schemes') || transcript.includes('योजना')) {
        navigate('/schemes');
      } else if (transcript.includes('status') || transcript.includes('स्थिति')) {
        navigate('/welfare');
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleSync = async () => {
    if (!isOnline) {
      alert(t('connectToInternetToSync'));
      return;
    }
    setIsSyncing(true);
    try {
      await loadData();
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const downloadEWallet = () => {
    const txSummary = transactions.slice(0, 3).map(tx => 
        `${new Date(tx.createdAt).toLocaleDateString()} - ${tx.senderId === user?.id ? t('sentTo') : t('receivedFrom')}: ₹${tx.amount}`
    ).join('\n');

    const content = `
${t('identityCard')} - Bharat Digital Wallet
------------------------------------------
${t('fullName')}: ${user?.name}
${t('decentralizedId')}: ${user?.did}
${t('balance')}: ₹${formatNumber(balance)}
${t('didStatus')}: ${t('verified')}
${t('location')}: ${address}
${t('date')}: ${new Date().toLocaleString()}
------------------------------------------
${t('recentTransactions')}:
${txSummary || t('noTransactions')}
------------------------------------------
This is a secure decentralized identity card.
    `;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `e-wallet-${user?.name}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black text-slate-900">{t('namaste')}, {user?.name?.split(' ')[0] || 'User'}!</h1>
          <div className="flex items-center gap-2 text-slate-500">
            <MapPin className="w-4 h-4 text-indigo-500" />
            <p className="text-lg font-medium">
              {locationLoading ? t('detectingLocation') : (locationError || `📍 ${address}`)}
            </p>
          </div>

          <div className="flex flex-wrap gap-2 mt-4 relative">
            <button 
              onClick={() => setLanguage("en")}
              className={`px-4 py-2 rounded-xl font-bold transition-all shadow-sm ${language === 'en' && isManual ? 'bg-indigo-600 text-white shadow-indigo-200' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
            >
              {t('english')}
            </button>
            <button 
              onClick={() => setLanguage("hi")}
              className={`px-4 py-2 rounded-xl font-bold transition-all shadow-sm ${language === 'hi' && isManual ? 'bg-emerald-600 text-white shadow-emerald-200' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
            >
              {t('hindi')}
            </button>
            <button 
              onClick={() => setIsManual(false)}
              className={`px-4 py-2 rounded-xl font-bold transition-all border shadow-sm ${!isManual ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'}`}
            >
              {t('local')}
            </button>

            <div className="relative">
              <button 
                onClick={() => setIsMoreLangsOpen(!isMoreLangsOpen)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all border shadow-sm ${MORE_LANGUAGES.some(l => l.code === language) && isManual ? 'bg-amber-600 text-white border-amber-600 shadow-amber-200' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
              >
                <Globe className="w-4 h-4" />
                <span>{t('moreLanguages')}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isMoreLangsOpen ? 'rotate-180' : ''}`} />
              </button>

              {isMoreLangsOpen && (
                <div className="absolute top-full left-0 mt-2 w-56 max-h-64 overflow-y-auto bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 grid grid-cols-1 gap-1">
                  {MORE_LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setIsMoreLangsOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 rounded-lg font-bold text-sm transition-all ${language === lang.code && isManual ? 'bg-amber-50 text-amber-700' : 'text-slate-600 hover:bg-slate-50'}`}
                    >
                      {lang.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="flex gap-3 relative">
          <button 
            onClick={handleSpeech}
            className={`p-4 rounded-2xl shadow-lg transition-all active:scale-95 ${isListening ? 'bg-rose-500 text-white animate-pulse' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
          >
            <Mic className="w-6 h-6" />
          </button>
          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-4 bg-white border border-slate-200 text-slate-600 rounded-2xl shadow-sm relative active:scale-95 transition-all"
            >
              <Bell className="w-6 h-6" />
              {notifications.length > 0 && (
                <span className="absolute top-3 right-3 w-3 h-3 bg-rose-500 border-2 border-white rounded-full"></span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute top-full right-0 mt-2 w-80 bg-white border border-slate-200 rounded-[2rem] shadow-2xl z-[60] p-4 space-y-3">
                <div className="flex justify-between items-center mb-2 px-2">
                  <h4 className="font-black text-slate-900">{t('notifications')}</h4>
                  <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-600">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {notifications.map(n => (
                  <div key={n.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100 transition-colors">
                    <p className="text-sm font-bold text-slate-900">{n.title}</p>
                    <p className="text-xs text-slate-600 mt-1">{n.message}</p>
                    <p className="text-[10px] text-slate-400 mt-2 font-bold">{n.time}</p>
                  </div>
                ))}
                {notifications.length === 0 && (
                  <p className="text-center text-slate-500 py-4 text-sm font-medium">{t('noNotifications')}</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Wallet Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-gradient-to-br from-indigo-700 to-indigo-900 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-500">
              <Wallet className="w-32 h-32" />
          </div>
          
          <div className="relative z-10 space-y-6">
            <div className="flex justify-between items-center">
              <span className="text-indigo-100 font-bold tracking-widest uppercase text-sm">{t('balance')}</span>
              {isOnline ? (
                <span className="flex items-center gap-1.5 text-[10px] font-bold bg-emerald-500/20 px-3 py-1 rounded-full text-emerald-300">
                  <Wifi className="w-3 h-3" /> {t('online')}
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-[10px] font-bold bg-amber-500/20 px-3 py-1 rounded-full text-amber-300">
                  <WifiOff className="w-3 h-3" /> {t('offline')}
                </span>
              )}
            </div>
            
            <div className="space-y-1">
              <h2 className="text-5xl font-black">₹<span data-number={balance}>{formatNumber(balance)}</span></h2>
              <p className="text-indigo-200 text-sm font-medium">{t('digitalIdentityVerified')}</p>
            </div>

            <div className="pt-4 flex gap-4">
              <button 
                  onClick={() => navigate('/wallet')}
                  className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-md py-4 rounded-2xl font-black text-lg transition-all"
              >
                  {t('wallet')}
              </button>
              <button 
                  onClick={handleSync}
                  disabled={isSyncing}
                  className="px-6 bg-white text-indigo-900 py-4 rounded-2xl font-black text-lg transition-all hover:bg-indigo-50 flex items-center justify-center"
              >
                  <RefreshCcw className={`w-6 h-6 ${isSyncing ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>

        <div className="bg-gradient-r from-indigo-600 to-indigo-800 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden flex flex-col justify-between group">
          <div className="absolute top-0 right-0 p-8 opacity-20 group-hover:scale-110 transition-transform duration-500">
            <QrCode className="w-32 h-32" />
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center gap-6 mb-8">
              <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center border-2 border-white/30 text-3xl font-black">
                {user?.name?.[0] || 'U'}
              </div>
              <div>
                <h3 className="text-2xl font-black">{user?.name}</h3>
                <p className="text-indigo-200 font-medium">{t('ruralCitizenIdentity')}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 p-4 rounded-2xl border border-white/10">
                <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mb-1">{t('didStatus')}</p>
                <div className="flex items-center gap-1.5 text-emerald-400 font-black text-sm">
                  <ShieldCheck className="w-4 h-4" /> {t('verified')}
                </div>
              </div>
              <div className="bg-white/10 p-4 rounded-2xl border border-white/10">
                <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mb-1">{t('location')}</p>
                <p className="text-white font-black text-sm truncate">{locationLoading ? 'Detecting...' : (address || t('India'))}</p>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-white/10 flex items-center justify-between">
            <button 
              onClick={downloadEWallet}
              className="flex items-center gap-2 text-[10px] font-bold text-indigo-100 hover:text-white transition-colors uppercase tracking-widest"
            >
              <Download className="w-4 h-4" />
              {t('downloadEWallet')}
            </button>
            <div className="text-right">
              <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mb-1">{t('decentralizedId')}</p>
              <p className="text-[10px] font-mono text-indigo-100 truncate pr-4">{user?.did}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Live Users Section */}
      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600">
            <UsersIcon className="w-6 h-6" />
          </div>
          <h3 className="text-2xl font-black text-slate-900">{t('liveUsers')}</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {users.map((lUser) => (
            <div key={lUser.id} className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <h4 className="font-black text-slate-900 text-xl mb-1">{lUser.name}</h4>
              <p className="text-[10px] font-mono text-slate-400 truncate mb-3">{lUser.did}</p>
              <p className="text-indigo-600 font-bold text-lg mb-1">₹{formatNumber(lUser.balance)}</p>
              <span className="text-[10px] font-bold text-slate-400 uppercase bg-slate-100 px-2 py-1 rounded-md">{t('liveUser')}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Transaction History Section */}
      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-100 p-2 rounded-lg text-emerald-600">
              <RefreshCcw className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-black text-slate-900">{t('recentTransactions')}</h3>
          </div>
          <button 
            onClick={() => navigate('/transactions')}
            className="text-indigo-600 font-bold hover:underline"
          >
            {t('viewFullHistory')}
          </button>
        </div>
        
        <div className="space-y-4">
          {transactions.length > 0 ? (
            transactions.map((tx) => (
              <div key={tx.id} className="flex justify-between items-center p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div>
                  <p className="font-black text-slate-900">
                    {tx.senderId === user?.id 
                      ? `${t('sentTo')} ${users.find((u:any) => u.id === tx.receiverId)?.name || 'User'}`
                      : `${t('receivedFrom')} ${users.find((u:any) => u.id === tx.senderId)?.name || 'User'}`}
                  </p>
                  <p className="text-xs text-slate-500 font-medium">
                    {new Date(tx.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`font-black ${tx.senderId === user?.id ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {tx.senderId === user?.id ? '-' : '+'} ₹{formatNumber(tx.amount)}
                  </p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{t(tx.status)}</p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-slate-500 font-medium text-center py-4">{t('noTransactions')}</p>
          )}
        </div>
      </div>

      {/* Main Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <ActionButton 
          icon={<Send className="w-8 h-8" />} 
          label={t('sendMoney')} 
          sublabel={t('instantOrOffline')}
          color="bg-emerald-50 text-emerald-700 border-emerald-100"
          onClick={() => navigate('/transaction')}
        />
        <ActionButton 
          icon={<Search className="w-8 h-8" />} 
          label={t('eligibility')} 
          sublabel={t('checkWelfareStatus')}
          color="bg-amber-50 text-amber-700 border-amber-100"
          onClick={() => navigate('/eligibility')}
        />
        <ActionButton 
          icon={<LayoutDashboard className="w-8 h-8" />} 
          label={t('welfareDashboard')} 
          sublabel={t('viewGovBenefits')}
          color="bg-blue-50 text-blue-700 border-blue-100"
          onClick={() => navigate('/welfare')}
        />
        <ActionButton 
          icon={<ShieldCheck className="w-8 h-8" />} 
          label={t('welfare')} 
          sublabel={t('findApplyBenefits')}
          color="bg-indigo-50 text-indigo-700 border-indigo-100"
          onClick={() => navigate('/schemes')}
        />
        <ActionButton 
          icon={<UserCheck className="w-8 h-8" />} 
          label={t('agentPortal')} 
          sublabel={t('secureFuture')}
          color="bg-rose-50 text-rose-700 border-rose-100"
          onClick={() => navigate('/agent')}
        />
      </div>
    </div>
  );
}

function ActionButton({ icon, label, sublabel, color, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className={`${color} border-2 p-8 rounded-[2.5rem] flex items-center gap-6 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-sm hover:shadow-md text-left w-full`}
    >
      <div className="p-5 rounded-3xl bg-white/50 shadow-inner">
        {icon}
      </div>
      <div>
        <h3 className="text-2xl font-black">{label}</h3>
        <p className="text-lg opacity-80 font-medium">{sublabel}</p>
      </div>
    </button>
  );
}
