import React, { useState, useEffect } from 'react';
import { IndianRupee, History, ShieldCheck, ChevronRight, CheckCircle2, Search, Filter } from 'lucide-react';
import { welfareService } from '../services/welfareService';
import { WelfarePayment, WelfareScheme } from '../types';
import { useTranslation } from '../hooks/useTranslation';

export default function WelfarePage() {
  const [payments, setPayments] = useState<WelfarePayment[]>([]);
  const [schemes, setSchemes] = useState<WelfareScheme[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'status' | 'history'>('status');
  const { t } = useTranslation();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [payData, schemeData] = await Promise.all([
          welfareService.getWelfarePayments(),
          welfareService.getSchemes()
        ]);
        setPayments(payData);
        setSchemes(schemeData);
        
        // Agent: Voice assistance request on page load
        welfareService.requestVoiceAssistance('WelfarePage');

        // Simulate deposit notification if there are payments
        if (payData.length > 0) {
          const latest = payData[0];
          welfareService.notifyDeposit(latest.amount, latest.schemeName);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t('welfareDashboard')}</h1>
        <p className="text-slate-600">{t('trackWelfareInfo')}</p>
      </div>

      <div className="flex gap-2 mb-8 bg-white p-1 rounded-2xl border border-slate-200 w-fit">
        <button 
          onClick={() => setActiveTab('status')}
          className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'status' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          {t('schemeStatus')}
        </button>
        <button 
          onClick={() => setActiveTab('history')}
          className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'history' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          {t('paymentHistory')}
        </button>
      </div>

      {activeTab === 'status' ? (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
             {schemes.filter(s => s.status === 'verified' || s.status === 'applied').length === 0 && (
                <div className="md:col-span-2 bg-indigo-50 border border-indigo-100 p-8 rounded-2xl text-center">
                  <ShieldCheck className="w-12 h-12 text-indigo-400 mx-auto mb-4" />
                  <p className="text-slate-600">{t('noSchemesApplied')}</p>
                  <button onClick={() => window.location.href='/dashboard'} className="mt-4 text-indigo-600 font-bold hover:underline">{t('viewAvailableSchemes')}</button>
                </div>
             )}
             {schemes.filter(s => s.status === 'verified' || s.status === 'applied').map((scheme) => (
               <div key={scheme.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${scheme.status === 'verified' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                      {scheme.status === 'verified' ? t('active') : t('pending')}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-xl mb-1">{t(scheme.title || scheme.name || '')}</h3>
                    <p className="text-sm text-slate-500">{t(scheme.id === '1' ? 'pmKisanDesc' : scheme.id === '2' ? 'mgnregaDesc' : 'dbtWelfareDesc')}</p>
                  </div>
                  
                  {/* Eligibility Tags */}
                  <div className="flex flex-wrap gap-2 py-2">
                    {scheme.id === '1' && (
                      <>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('smallFarmers')}</span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('validLandRecords')}</span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('aadharLinkedBank')}</span>
                      </>
                    )}
                    {scheme.id === '2' && (
                      <>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('mgnregaEligibility1')}</span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('mgnregaEligibility2')}</span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('mgnregaEligibility3')}</span>
                      </>
                    )}
                    {scheme.id === '3' && (
                      <>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('dbtEligibility1')}</span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('dbtEligibility2')}</span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-[10px] font-bold uppercase">{t('dbtEligibility3')}</span>
                      </>
                    )}
                  </div>

                  <div className="bg-slate-50 p-4 rounded-xl">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t('benefit')}</p>
                    <p className="font-bold text-slate-800">
                      {scheme.id === '1' ? t('annualSupport6000') : scheme.id === '2' ? t('guaranteedWageEmployment') : t('eliminationMiddleman')}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-xs font-bold text-slate-400">{t('nextPayout')}: {t('tbd')}</span>
                    <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-indigo-700 transition-colors">
                      {t('applyNow')}
                    </button>
                  </div>
               </div>
             ))}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50">
            <h2 className="font-bold text-slate-800 flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-600" />
              {t('dbtPayments')}
            </h2>
          </div>
          <div className="divide-y divide-slate-100">
            {payments.length === 0 ? (
              <div className="p-12 text-center">
                <IndianRupee className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-slate-500">{t('noPaymentHistory')}</p>
              </div>
            ) : (
              payments.map((payment) => (
                <div key={payment.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                      <IndianRupee className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800">{t(payment.schemeName)}</h4>
                      <p className="text-sm text-slate-500">{new Date(payment.paidAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-black text-slate-800">+₹<span data-number={payment.amount}>{payment.amount}</span></p>
                    <p className={`text-[10px] font-bold text-emerald-600 uppercase tracking-wider`}>{t('deposited')}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
